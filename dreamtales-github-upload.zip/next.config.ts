import type { NextConfig } from "next";

// Every page in this app depends on the signed-in parent, so pages render
// dynamically (no Cache Components / partial prefetching).
const nextConfig: NextConfig = {
  serverExternalPackages: ["@prisma/client"],
};

export default nextConfig;
