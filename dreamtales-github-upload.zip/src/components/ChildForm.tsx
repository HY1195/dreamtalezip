"use client";

import { useState } from "react";
import { api, ApiError } from "@/lib/client";

export type ChildValues = {
  name: string;
  pronunciation: string;
  age: number;
  favorites: string[];
};

// Create or edit a child profile. Only a first name or nickname is asked for
// (data minimization, PRD §8.5).
export default function ChildForm({
  childId,
  initial,
  submitLabel,
  onSaved,
  onCancel,
}: {
  childId?: string;
  initial?: Partial<ChildValues>;
  submitLabel: string;
  onSaved: (note: string | null) => void;
  onCancel?: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [pronunciation, setPronunciation] = useState(initial?.pronunciation ?? "");
  const [age, setAge] = useState<number>(initial?.age ?? 4);
  const [favorites, setFavorites] = useState<string[]>(initial?.favorites ?? []);
  const [favInput, setFavInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function addFavorite() {
    const v = favInput.trim();
    if (!v || favorites.includes(v) || favorites.length >= 10) return;
    setFavorites([...favorites, v]);
    setFavInput("");
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const body = { name, pronunciation: pronunciation || null, age, favorites };
    try {
      const res = await api<{ note: string | null }>(childId ? `/api/children/${childId}` : "/api/children", {
        method: childId ? "PATCH" : "POST",
        body,
      });
      onSaved(res.note);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="group" onSubmit={submit}>
      <div>
        <label htmlFor="child-name">Child&apos;s first name or nickname</label>
        <input id="child-name" type="text" required maxLength={30} value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div>
        <label htmlFor="child-pron">How to say it (optional)</label>
        <input
          id="child-pron"
          type="text"
          maxLength={40}
          placeholder="e.g. 'Shiv-on' for Siobhan"
          value={pronunciation}
          onChange={(e) => setPronunciation(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="child-age">Age</label>
        <select id="child-age" value={age} onChange={(e) => setAge(Number(e.target.value))}>
          {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="child-fav">Favorite things (optional)</label>
        <div className="row">
          <input
            id="child-fav"
            type="text"
            maxLength={40}
            placeholder="e.g. dinosaurs, a teddy called Bobo"
            value={favInput}
            onChange={(e) => setFavInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                addFavorite();
              }
            }}
            style={{ flex: 1 }}
          />
          <button type="button" className="btn" onClick={addFavorite} disabled={!favInput.trim()}>
            Add
          </button>
        </div>
        {favorites.length > 0 && (
          <div className="chips" style={{ marginTop: 8 }}>
            {favorites.map((f) => (
              <button
                type="button"
                key={f}
                className="chip"
                aria-label={`Remove ${f}`}
                onClick={() => setFavorites(favorites.filter((x) => x !== f))}
              >
                {f} ✕
              </button>
            ))}
          </div>
        )}
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row">
        <button className="btn primary" disabled={busy || !name.trim()}>
          {busy ? "Saving…" : submitLabel}
        </button>
        {onCancel && (
          <button type="button" className="btn quiet" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
