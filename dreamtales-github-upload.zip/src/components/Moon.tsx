// The one bold element of the design: a moon whose phase shows story progress.
// progress 0 = full moon (story starting), 1 = thin crescent (story ending).

export default function Moon({ progress = 0, glow = false, label }: { progress?: number; glow?: boolean; label?: string }) {
  const p = Math.min(1, Math.max(0, progress));
  const r = 50;
  // A shadow disc slides in from the right; stop just short of a new moon so a
  // sliver of light always remains.
  const shadowCx = 100 + r * 2 - p * r * 1.85;
  const id = "moon-mask";
  return (
    <svg viewBox="0 0 200 200" role={label ? "img" : undefined} aria-label={label} aria-hidden={label ? undefined : true}>
      <defs>
        <radialGradient id="moon-light" cx="38%" cy="36%" r="70%">
          <stop offset="0%" stopColor="#fbefd2" />
          <stop offset="70%" stopColor="#efd59a" />
          <stop offset="100%" stopColor="#d9b56b" />
        </radialGradient>
        <radialGradient id="moon-halo" cx="50%" cy="50%" r="50%">
          <stop offset="55%" stopColor="#f0b95b" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#f0b95b" stopOpacity="0" />
        </radialGradient>
        <mask id={id}>
          <rect width="200" height="200" fill="white" />
          <circle cx={shadowCx} cy="100" r={r + 1} fill="black" />
        </mask>
      </defs>
      <circle className={glow ? "moon-glow" : undefined} cx="100" cy="100" r="96" fill="url(#moon-halo)" opacity={1 - p * 0.7} />
      {/* earthshine: the unlit part stays faintly visible */}
      <circle cx="100" cy="100" r={r} fill="#232a4d" />
      <circle cx="100" cy="100" r={r} fill="url(#moon-light)" mask={`url(#${id})`} />
    </svg>
  );
}
