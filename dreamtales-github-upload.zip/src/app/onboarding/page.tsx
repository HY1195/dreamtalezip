import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import Onboarding from "./Onboarding";

export default async function OnboardingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const hasChild = (await db.child.count({ where: { userId: user.id } })) > 0;
  if (user.parentalConsentAt && hasChild) redirect("/app");
  return <Onboarding consented={Boolean(user.parentalConsentAt)} />;
}
