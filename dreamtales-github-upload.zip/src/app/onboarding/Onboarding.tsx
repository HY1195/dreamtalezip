"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import ChildForm from "@/components/ChildForm";
import { api, ApiError } from "@/lib/client";

// First-time setup (PRD Journey A1): adult + parental consent, then the first child.
export default function Onboarding({ consented }: { consented: boolean }) {
  const router = useRouter();
  const [step, setStep] = useState<"consent" | "child">(consented ? "child" : "consent");
  const [adult, setAdult] = useState(false);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function giveConsent() {
    setBusy(true);
    setError(null);
    try {
      await api("/api/account/consent", {
        body: { adult: true, consent: true, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
      });
      setStep("child");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="page" style={{ paddingTop: 40 }}>
      {step === "consent" ? (
        <div className="panel">
          <h1>Before we start</h1>
          <p className="dim">
            DreamTales is for parents and caregivers. To personalize stories we store your child&apos;s first name (or
            nickname), age and favorite things. We never ask for photos, surnames, birthdays or locations, and we never
            use children&apos;s data for ads.
          </p>
          <label className="check">
            <input type="checkbox" checked={adult} onChange={(e) => setAdult(e.target.checked)} />
            <span>I am 18 or older and the parent or legal guardian of the children I add.</span>
          </label>
          <label className="check">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span>
              I consent to DreamTales storing my children&apos;s first names, ages and favorite things to create their
              stories, as described in the <a href="/privacy">Privacy Policy</a>. I can delete this data at any time.
            </span>
          </label>
          {error && <p className="error">{error}</p>}
          <button className="btn primary block" disabled={!adult || !consent || busy} onClick={giveConsent}>
            Continue
          </button>
        </div>
      ) : (
        <div className="panel">
          <h1>Who are the stories for?</h1>
          <p className="dim">You can add brothers and sisters later.</p>
          <ChildForm submitLabel="Save and continue" onSaved={() => router.push("/app")} />
        </div>
      )}
    </main>
  );
}
