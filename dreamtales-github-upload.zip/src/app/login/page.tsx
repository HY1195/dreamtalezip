import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import LoginForm from "./LoginForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; signedout?: string }>;
}) {
  const user = await getCurrentUser();
  if (user) redirect(user.parentalConsentAt ? "/app" : "/onboarding");
  const { error, signedout } = await searchParams;
  return (
    <main className="page" style={{ paddingTop: 48 }}>
      <h1>Sign in to DreamTales</h1>
      {error === "expired" && <p className="error">That link has expired or was already used. Please request a new one.</p>}
      {signedout === "all" && <p className="success">All devices have been signed out.</p>}
      <LoginForm />
    </main>
  );
}
