"use client";

import { useState } from "react";
import { api, ApiError } from "@/lib/client";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/request", { body: { email } });
      setSent(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <div className="panel">
        <h2>Check your email</h2>
        <p>
          We sent a sign-in link to <strong>{email}</strong>. Open it on this device to continue.
        </p>
        <button className="btn quiet" onClick={() => setSent(false)}>
          Use a different email
        </button>
      </div>
    );
  }

  return (
    <form className="panel" onSubmit={submit}>
      <p className="dim">No password needed. We&apos;ll email you a link that signs you in.</p>
      <div>
        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      {error && <p className="error">{error}</p>}
      <button className="btn primary block" disabled={busy || !email}>
        {busy ? "Sending…" : "Email me a sign-in link"}
      </button>
      <p className="small dim">
        Anyone you share this sign-in with (a partner, grandparent or babysitter) can use DreamTales with your
        children&apos;s profiles.
      </p>
    </form>
  );
}
