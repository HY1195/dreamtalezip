import { NextResponse } from "next/server";
import { z } from "zod";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";
import { expireIfStale, publicStory } from "@/lib/stories";
import { deleteAudio } from "@/lib/storage";

type Ctx = { params: Promise<{ id: string }> };

async function ownedStory(id: string, userId: string) {
  const story = await db.story.findFirst({
    where: { id, userId },
    include: { child: { select: { name: true, color: true } } },
  });
  if (!story) throw new HttpError(404, "Story not found.", "not_found");
  return story;
}

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const story = await ownedStory(id, user.id);
  const fresh = await expireIfStale(story);
  return NextResponse.json({ story: publicStory({ ...fresh, child: story.child }) });
});

const Patch = z.object({
  saved: z.boolean().optional(),
  rating: z.union([z.literal(1), z.literal(-1), z.null()]).optional(),
  ratingReason: z.enum(["loved_it", "too_long", "too_short", "too_scary", "too_simple", "too_hard", "other"]).nullish(),
  reported: z.literal(true).optional(),
});

// Save to library, rate, or report a story (PRD §6.1 feedback, §8.4 reporting).
export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const story = await ownedStory(id, user.id);
  const body = Patch.parse(await req.json());
  const updated = await db.story.update({
    where: { id: story.id },
    data: {
      saved: body.saved,
      rating: body.rating,
      ratingReason: body.ratingReason,
      reported: body.reported,
      // A reported story is refunded so the parent can get another one for free.
      countsTowardQuota: body.reported ? false : undefined,
    },
  });
  if (body.reported) {
    console.warn(`[review-queue] story ${story.id} reported by parent`);
  }
  return NextResponse.json({ story: publicStory({ ...updated, child: story.child }) });
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const story = await ownedStory(id, user.id);
  if (story.audioKey) await deleteAudio(story.audioKey);
  await db.story.delete({ where: { id: story.id } });
  return NextResponse.json({ ok: true });
});
