import { NextResponse } from "next/server";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";
import { getAudio } from "@/lib/storage";

type Ctx = { params: Promise<{ id: string }> };

// Replays a saved story. No AI cost (PRD §8.6); served from the Blob CDN.
export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const story = await db.story.findFirst({ where: { id, userId: user.id } });
  if (!story?.audioKey) throw new HttpError(404, "Audio not found.", "not_found");

  const audio = await getAudio(story.audioKey);
  if (!audio) throw new HttpError(404, "Audio not found.", "not_found");
  if ("url" in audio) return NextResponse.redirect(audio.url);
  return new Response(new Uint8Array(audio.data), {
    headers: {
      "Content-Type": "audio/mpeg",
      "Content-Length": String(audio.data.byteLength),
      "Accept-Ranges": "none",
      "Cache-Control": "private, max-age=3600",
    },
  });
});
