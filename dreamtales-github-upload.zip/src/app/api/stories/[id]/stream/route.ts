import { NextResponse } from "next/server";
import { waitUntil } from "@vercel/functions";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";
import { runStoryPipeline } from "@/lib/story/pipeline";

// Generating + voicing a 10-minute story takes well under this, because
// generation runs much faster than real-time playback.
export const maxDuration = 300;

type Ctx = { params: Promise<{ id: string }> };

// Streams a NEW story's audio (audio/mpeg) to the browser while it's being
// written and voiced. The <audio> element starts playing after the first sentence.
export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const story = await db.story.findFirst({ where: { id, userId: user.id } });
  if (!story) throw new HttpError(404, "Story not found.", "not_found");

  if (story.status === "ready") {
    return NextResponse.redirect(new URL(`/api/stories/${id}/audio`, _req.url));
  }

  // Claim the story so it is generated exactly once (double taps, two devices).
  const claimed = await db.story.updateMany({
    where: { id, status: "pending" },
    data: { status: "streaming" },
  });
  if (claimed.count === 0) {
    throw new HttpError(409, "This story is already playing on another screen.", "already_streaming");
  }

  let controller!: ReadableStreamDefaultController<Uint8Array>;
  let listening = true;
  const body = new ReadableStream<Uint8Array>({
    start(c) {
      controller = c;
    },
    cancel() {
      // Parent closed the page: keep generating so the story is saved.
      listening = false;
    },
  });

  const work = runStoryPipeline(id, (bytes) => {
    if (!listening) return;
    try {
      controller.enqueue(bytes);
    } catch {
      listening = false;
    }
  })
    .then(() => {
      if (listening) controller.close();
    })
    .catch(async (err) => {
      console.error(`[story ${id}] pipeline crashed`, err);
      await db.story
        .update({ where: { id }, data: { status: "failed", countsTowardQuota: false } })
        .catch(() => {});
      if (listening) controller.error(err);
    });

  // Keep the function alive until the story is saved, even if the client leaves.
  waitUntil(work);

  return new Response(body, {
    headers: {
      "Content-Type": "audio/mpeg",
      "Cache-Control": "no-store",
      "X-Accel-Buffering": "no",
    },
  });
});
