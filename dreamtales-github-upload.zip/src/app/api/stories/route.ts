import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { MAX_REQUEST_CHARS, STORY_LENGTHS, STYLE_IDS } from "@/lib/config";
import { db } from "@/lib/db";
import { handler, rateLimit } from "@/lib/http";
import { getQuota, isPaid } from "@/lib/quota";
import { publicStory } from "@/lib/stories";
import { checkParentInput } from "@/lib/story/safety";
import { getVoice } from "@/lib/voices";

const CreateStory = z.object({
  childId: z.string().min(1),
  styles: z.array(z.enum(STYLE_IDS)).min(1).max(3),
  lengthMinutes: z.number().refine((n) => (STORY_LENGTHS as readonly number[]).includes(n), "Invalid length"),
  voiceId: z.string().min(1),
  request: z.string().trim().max(MAX_REQUEST_CHARS).optional(),
  useFavorites: z.boolean().default(true),
  // Sent by the client so a double tap on "Start" only creates one story.
  idempotencyKey: z.string().min(8).max(64),
});

// Create a new story. The audio itself is streamed by GET /api/stories/[id]/stream.
export const POST = handler(async (req: Request) => {
  const user = await requireConsentedUser();
  rateLimit(`story:${user.id}`, 10, 60_000);
  const input = CreateStory.parse(await req.json());

  // Double tap: return the story that was already created.
  const existing = await db.story.findUnique({
    where: { userId_idempotencyKey: { userId: user.id, idempotencyKey: input.idempotencyKey } },
  });
  if (existing) return NextResponse.json({ story: publicStory(existing) });

  const child = await db.child.findFirst({ where: { id: input.childId, userId: user.id } });
  if (!child) throw new HttpError(404, "Child not found.", "not_found");

  const voice = getVoice(input.voiceId);
  if (!voice) throw new HttpError(400, "Unknown voice.", "invalid_voice");
  if (voice.premium && !isPaid(user)) {
    throw new HttpError(402, "That voice is part of DreamTales Plus.", "premium_required");
  }

  const quota = await getQuota(user);
  if (quota.remaining <= 0) {
    return NextResponse.json(
      {
        error:
          quota.plan === "free"
            ? "You've used this week's free stories. Saved stories can still be replayed anytime."
            : "You've reached this month's story limit.",
        code: "quota_exceeded",
        quota,
      },
      { status: 402 },
    );
  }

  // Free-text requests are checked before any story is written (PRD §8.4).
  if (input.request) {
    const verdict = await checkParentInput(input.request);
    if (!verdict.allowed) {
      return NextResponse.json(
        {
          error: "Let's pick a cozier idea for bedtime.",
          code: "request_blocked",
          suggestion: verdict.safe_alternative || null,
        },
        { status: 422 },
      );
    }
  }

  const settings = {
    styles: input.styles,
    lengthMinutes: input.lengthMinutes,
    voiceId: input.voiceId,
    useFavorites: input.useFavorites,
  };

  try {
    const story = await db.story.create({
      data: {
        userId: user.id,
        childId: child.id,
        idempotencyKey: input.idempotencyKey,
        styles: input.styles,
        lengthMinutes: input.lengthMinutes,
        voiceId: input.voiceId,
        request: input.request || null,
        useFavorites: input.useFavorites,
      },
    });
    // Remember settings for one-tap "Tonight's story" (PRD FR-14).
    await db.child.update({ where: { id: child.id }, data: { lastSettings: settings } });
    return NextResponse.json({ story: publicStory(story) }, { status: 201 });
  } catch (err) {
    // Two taps raced past the idempotency check: return the winner.
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      const story = await db.story.findUniqueOrThrow({
        where: { userId_idempotencyKey: { userId: user.id, idempotencyKey: input.idempotencyKey } },
      });
      return NextResponse.json({ story: publicStory(story) });
    }
    throw err;
  }
});

// The library: saved and recent stories, optionally for one child.
export const GET = handler(async (req: Request) => {
  const user = await requireConsentedUser();
  const url = new URL(req.url);
  const childId = url.searchParams.get("childId") ?? undefined;
  const savedOnly = url.searchParams.get("saved") === "1";
  const stories = await db.story.findMany({
    where: { userId: user.id, childId, status: "ready", ...(savedOnly ? { saved: true } : {}) },
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { child: { select: { name: true, color: true } } },
  });
  return NextResponse.json({ stories: stories.map(publicStory) });
});
