import { NextResponse } from "next/server";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { ageNote, ChildInput, moderateChild, pickColor } from "@/lib/children";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";

const MAX_CHILDREN = 8;

export const POST = handler(async (req: Request) => {
  const user = await requireConsentedUser();
  const input = ChildInput.parse(await req.json());
  const count = await db.child.count({ where: { userId: user.id } });
  if (count >= MAX_CHILDREN) throw new HttpError(400, "That's the maximum number of children.", "too_many_children");
  await moderateChild(input);
  const child = await db.child.create({
    data: {
      userId: user.id,
      name: input.name,
      pronunciation: input.pronunciation || null,
      age: input.age,
      favorites: input.favorites,
      color: input.color ?? pickColor(count),
    },
  });
  return NextResponse.json({ child, note: ageNote(child.age) }, { status: 201 });
});
