import { NextResponse } from "next/server";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { ageNote, ChildInput, moderateChild } from "@/lib/children";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";

// Edit a child profile. Deleting a child needs email confirmation
// (see /api/account/confirm) so a shared caretaker login can't do it by accident.
export const PATCH = handler(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireConsentedUser();
  const { id } = await ctx.params;
  const existing = await db.child.findFirst({ where: { id, userId: user.id } });
  if (!existing) throw new HttpError(404, "Not found.", "not_found");

  const input = ChildInput.parse(await req.json());
  const changedWords =
    input.name !== existing.name ||
    (input.pronunciation ?? null) !== existing.pronunciation ||
    input.favorites.join("|") !== existing.favorites.join("|");
  if (changedWords) await moderateChild(input);

  const child = await db.child.update({
    where: { id },
    data: {
      name: input.name,
      pronunciation: input.pronunciation || null,
      age: input.age,
      favorites: input.favorites,
      color: input.color ?? existing.color,
    },
  });
  return NextResponse.json({ child, note: ageNote(child.age) });
});
