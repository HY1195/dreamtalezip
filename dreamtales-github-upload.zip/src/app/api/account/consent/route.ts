import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";

// COPPA: the parent confirms they're an adult and consents to storing their
// children's first names, ages and interests (PRD §8.5).
// NOTE: the verifiable parental consent METHOD is pending legal review
// (PRD §13.2). This checkbox flow is the placeholder to replace.
const Body = z.object({
  adult: z.literal(true),
  consent: z.literal(true),
  timezone: z.string().max(64).optional(),
});

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const body = Body.parse(await req.json());
  const now = new Date();
  await db.user.update({
    where: { id: user.id },
    data: {
      adultConfirmedAt: user.adultConfirmedAt ?? now,
      parentalConsentAt: user.parentalConsentAt ?? now,
      timezone: body.timezone && isTimeZone(body.timezone) ? body.timezone : undefined,
    },
  });
  return NextResponse.json({ ok: true });
});

function isTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}
