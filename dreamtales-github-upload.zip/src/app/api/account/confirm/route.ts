import { NextResponse } from "next/server";
import { z } from "zod";
import { hashToken, HttpError, newToken, requireUser } from "@/lib/auth";
import { appUrl } from "@/lib/config";
import { db } from "@/lib/db";
import { sendEmail } from "@/lib/email";
import { handler, rateLimit } from "@/lib/http";
import { deleteAudio } from "@/lib/storage";
import { stripe } from "@/lib/stripe";

// Sensitive actions are confirmed by a link sent to the account owner's email
// (PRD §11 corner cases), because the login may be shared with caretakers.

const Body = z.object({
  action: z.enum(["delete_child", "delete_account", "signout_all"]),
  targetId: z.string().optional(),
});

const DESCRIPTIONS: Record<z.infer<typeof Body>["action"], string> = {
  delete_child: "permanently delete a child's profile and all of their stories",
  delete_account: "permanently delete your DreamTales account, all children's profiles and stories, and cancel your subscription",
  signout_all: "sign out every device using your DreamTales account",
};

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  rateLimit(`confirm:${user.id}`, 5, 15 * 60_000);
  const body = Body.parse(await req.json());
  let what = DESCRIPTIONS[body.action];
  if (body.action === "delete_child") {
    const child = await db.child.findFirst({ where: { id: body.targetId, userId: user.id } });
    if (!child) throw new HttpError(404, "Child not found.", "not_found");
    what = `permanently delete ${child.name}'s profile and all of their stories`;
  }
  const token = newToken();
  await db.actionToken.create({
    data: {
      userId: user.id,
      action: body.action,
      targetId: body.targetId ?? null,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 30 * 60_000),
    },
  });
  const link = appUrl(`/api/account/confirm?token=${encodeURIComponent(token)}`);
  await sendEmail(
    user.email,
    "Please confirm your DreamTales request",
    `Someone using your DreamTales account asked to ${what}.\n\nTo confirm, open this link within 30 minutes:\n${link}\n\nIf this wasn't you, ignore this email and nothing will change.`,
  );
  return NextResponse.json({ ok: true });
});

// The owner clicked the confirmation link.
export async function GET(req: Request) {
  const token = new URL(req.url).searchParams.get("token") ?? "";
  const record = await db.actionToken.findUnique({ where: { tokenHash: hashToken(token) } });
  if (!record || record.usedAt || record.expiresAt < new Date()) {
    return NextResponse.redirect(appUrl("/app/settings?confirm=expired"));
  }
  const used = await db.actionToken.updateMany({
    where: { id: record.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (used.count === 0) return NextResponse.redirect(appUrl("/app/settings?confirm=expired"));

  switch (record.action) {
    case "signout_all":
      await db.user.update({ where: { id: record.userId }, data: { sessionVersion: { increment: 1 } } });
      return NextResponse.redirect(appUrl("/login?signedout=all"));

    case "delete_child": {
      const child = await db.child.findFirst({ where: { id: record.targetId ?? "", userId: record.userId } });
      if (child) {
        const stories = await db.story.findMany({ where: { childId: child.id }, select: { audioKey: true } });
        await Promise.all(stories.map((s) => (s.audioKey ? deleteAudio(s.audioKey) : null)));
        await db.child.delete({ where: { id: child.id } });
      }
      return NextResponse.redirect(appUrl("/app/settings?confirm=child_deleted"));
    }

    case "delete_account": {
      const user = await db.user.findUnique({ where: { id: record.userId } });
      if (user) {
        if (user.stripeSubscriptionId && process.env.STRIPE_SECRET_KEY) {
          await stripe().subscriptions.cancel(user.stripeSubscriptionId).catch((e) => console.error(e));
        }
        const stories = await db.story.findMany({ where: { userId: user.id }, select: { audioKey: true } });
        await Promise.all(stories.map((s) => (s.audioKey ? deleteAudio(s.audioKey) : null)));
        await db.loginToken.deleteMany({ where: { email: user.email } });
        await db.user.delete({ where: { id: user.id } }); // cascades to children, stories, tokens
      }
      return NextResponse.redirect(appUrl("/?deleted=1"));
    }
  }
  return NextResponse.redirect(appUrl("/app/settings"));
}
