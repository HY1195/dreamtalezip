import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";

// Data export (PRD FR-15): everything we store about the family, as JSON.
export const GET = handler(async () => {
  const user = await requireUser();
  const data = await db.user.findUniqueOrThrow({
    where: { id: user.id },
    select: {
      email: true,
      createdAt: true,
      adultConfirmedAt: true,
      parentalConsentAt: true,
      plan: true,
      children: {
        select: {
          name: true,
          pronunciation: true,
          age: true,
          favorites: true,
          createdAt: true,
          stories: {
            select: {
              title: true,
              text: true,
              styles: true,
              lengthMinutes: true,
              request: true,
              saved: true,
              rating: true,
              createdAt: true,
            },
          },
        },
      },
    },
  });
  return new Response(JSON.stringify(data, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": 'attachment; filename="dreamtales-data.json"',
    },
  });
});
