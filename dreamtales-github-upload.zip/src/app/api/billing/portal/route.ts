import { NextResponse } from "next/server";
import { HttpError, requireUser } from "@/lib/auth";
import { appUrl } from "@/lib/config";
import { handler } from "@/lib/http";
import { stripe } from "@/lib/stripe";

// Stripe Customer Portal: update card, see invoices, cancel.
export const POST = handler(async () => {
  const user = await requireUser();
  if (!user.stripeCustomerId) throw new HttpError(400, "No subscription found.", "no_subscription");
  const session = await stripe().billingPortal.sessions.create({
    customer: user.stripeCustomerId,
    return_url: appUrl("/app/settings"),
  });
  return NextResponse.json({ url: session.url });
});
