import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { syncSubscription } from "@/lib/billing";
import { handler } from "@/lib/http";
import { stripe } from "@/lib/stripe";

const Body = z.object({ sessionId: z.string().startsWith("cs_") });

// Called by the app right after Checkout succeeds, so the upgrade works
// immediately even if the webhook is delayed (PRD corner case).
export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const { sessionId } = Body.parse(await req.json());
  const session = await stripe().checkout.sessions.retrieve(sessionId);
  if (session.client_reference_id !== user.id || !session.subscription) {
    return NextResponse.json({ paid: false });
  }
  const subId = typeof session.subscription === "string" ? session.subscription : session.subscription.id;
  await syncSubscription(await stripe().subscriptions.retrieve(subId));
  return NextResponse.json({ paid: true });
});
