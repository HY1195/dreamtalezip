import { NextResponse } from "next/server";
import { HttpError, requireConsentedUser } from "@/lib/auth";
import { appUrl } from "@/lib/config";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";
import { isPaid } from "@/lib/quota";
import { stripe } from "@/lib/stripe";

// Starts Stripe Checkout for DreamTales Plus ($5.99/month, USD only).
export const POST = handler(async () => {
  const user = await requireConsentedUser();
  if (isPaid(user)) throw new HttpError(400, "You already have DreamTales Plus.", "already_paid");
  const price = process.env.STRIPE_PRICE_ID_MONTHLY;
  if (!price) throw new HttpError(503, "Payments aren't set up yet.", "billing_unavailable");

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe().customers.create({ email: user.email, metadata: { userId: user.id } });
    customerId = customer.id;
    await db.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } });
  }

  const session = await stripe().checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price, quantity: 1 }],
    client_reference_id: user.id,
    // US-only: collect the billing address. Add a Stripe Radar rule to block
    // non-US cards (see README).
    billing_address_collection: "required",
    customer_update: { address: "auto" },
    automatic_tax: { enabled: true },
    allow_promotion_codes: true,
    success_url: appUrl("/app?checkout=success&session_id={CHECKOUT_SESSION_ID}"),
    cancel_url: appUrl("/app/settings?checkout=cancelled"),
  });
  return NextResponse.json({ url: session.url });
});
