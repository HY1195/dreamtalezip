import { NextResponse } from "next/server";
import { z } from "zod";
import { createLoginToken } from "@/lib/auth";
import { appUrl } from "@/lib/config";
import { sendEmail } from "@/lib/email";
import { clientIp, handler, rateLimit } from "@/lib/http";

const Body = z.object({ email: z.email().max(254) });

// Step 1 of sign-in: email the parent a one-time link.
export const POST = handler(async (req: Request) => {
  rateLimit(`login:${clientIp(req)}`, 10, 15 * 60_000);

  // US-only launch (PRD §1.1). Vercel sets this header in production.
  const country = req.headers.get("x-vercel-ip-country");
  if (country && country !== "US") {
    return NextResponse.json(
      { error: "DreamTales is currently available in the US only.", code: "region_unavailable" },
      { status: 403 },
    );
  }

  const { email } = Body.parse(await req.json());
  const normalized = email.trim().toLowerCase();
  rateLimit(`login:${normalized}`, 5, 15 * 60_000);

  const token = await createLoginToken(normalized);
  const link = appUrl(`/api/auth/verify?token=${encodeURIComponent(token)}`);
  await sendEmail(
    normalized,
    "Your DreamTales sign-in link",
    `Tap this link to sign in to DreamTales:\n\n${link}\n\nThe link works once and expires in 15 minutes. If you didn't ask for it, you can ignore this email.`,
  );
  return NextResponse.json({ ok: true });
});
