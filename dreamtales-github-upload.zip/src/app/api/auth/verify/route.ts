import { NextResponse } from "next/server";
import { consumeLoginToken, startSession } from "@/lib/auth";
import { appUrl } from "@/lib/config";

// Step 2 of sign-in: the parent clicked the emailed link.
export async function GET(req: Request) {
  const token = new URL(req.url).searchParams.get("token");
  const user = token ? await consumeLoginToken(token) : null;
  if (!user) {
    return NextResponse.redirect(appUrl("/login?error=expired"));
  }
  await startSession(user);
  const next = user.parentalConsentAt ? "/app" : "/onboarding";
  return NextResponse.redirect(appUrl(next));
}
