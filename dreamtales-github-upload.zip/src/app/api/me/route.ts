import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/http";
import { getQuota, isPaid } from "@/lib/quota";
import { VOICES } from "@/lib/voices";

// Everything the app screens need about the signed-in family in one call.
export const GET = handler(async () => {
  const user = await requireUser();
  const [children, quota] = await Promise.all([
    db.child.findMany({ where: { userId: user.id }, orderBy: { createdAt: "asc" } }),
    getQuota(user),
  ]);
  const paid = isPaid(user);
  return NextResponse.json({
    user: {
      email: user.email,
      consented: Boolean(user.parentalConsentAt),
      paid,
      subscriptionStatus: user.subscriptionStatus,
      currentPeriodEnd: user.currentPeriodEnd,
    },
    quota,
    children: children.map((c) => ({
      id: c.id,
      name: c.name,
      pronunciation: c.pronunciation,
      age: c.age,
      favorites: c.favorites,
      color: c.color,
      lastSettings: c.lastSettings,
    })),
    voices: VOICES.map((v) => ({
      id: v.id,
      label: v.label,
      description: v.description,
      premium: v.premium,
      available: paid || !v.premium,
    })),
  });
});
