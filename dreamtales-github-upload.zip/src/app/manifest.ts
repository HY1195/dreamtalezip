import type { MetadataRoute } from "next";

// Installable PWA: "Add to Home Screen" gives a full-screen app feel and more
// reliable background audio on phones (PRD §8.8).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "DreamTales",
    short_name: "DreamTales",
    description: "Personal bedtime stories, read aloud.",
    start_url: "/app",
    display: "standalone",
    background_color: "#14112b",
    theme_color: "#14112b",
    icons: [{ src: "/favicon.ico", sizes: "any", type: "image/x-icon" }],
  };
}
