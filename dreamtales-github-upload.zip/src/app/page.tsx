import Link from "next/link";
import { redirect } from "next/navigation";
import Moon from "@/components/Moon";
import { getCurrentUser } from "@/lib/auth";

export default async function Landing({ searchParams }: { searchParams: Promise<{ deleted?: string }> }) {
  const user = await getCurrentUser();
  if (user) redirect(user.parentalConsentAt ? "/app" : "/onboarding");
  const { deleted } = await searchParams;

  return (
    <main className="page" style={{ paddingTop: 48 }}>
      {deleted && <p className="success">Your account and all of its data have been deleted.</p>}
      <div className="moon-wrap" style={{ width: 160 }}>
        <Moon glow />
      </div>
      <div className="group">
        <h1>Tonight&apos;s story stars your child.</h1>
        <p className="dim">
          Tell DreamTales your child&apos;s name, age and favorite things. In a few seconds a calm voice starts reading a
          brand-new story where they&apos;re the hero, and it always ends sleepy and safe.
        </p>
      </div>
      <Link href="/login" className="btn primary big block">
        Make a free story
      </Link>
      <ul className="list dim small">
        <li>3 new stories free every week. Saved stories replay anytime.</li>
        <li>Written for ages 2 to 10. Every story is checked to keep it gentle.</li>
        <li>Available in the US, in English.</li>
      </ul>
    </main>
  );
}
