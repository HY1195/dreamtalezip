// PLACEHOLDER. The real Privacy Policy and Terms must be written for a
// children's product and reviewed by a lawyer before launch (PRD §8.5, §13.2).
export default function Privacy() {
  return (
    <main className="page">
      <h1>Privacy</h1>
      <p className="dim">Draft placeholder. The full policy will be written with legal counsel before launch.</p>
      <ul className="list">
        <li>We store a parent&apos;s email, and each child&apos;s first name or nickname, age and favorite things.</li>
        <li>Children&apos;s information is used only to write their stories. No ads, and we never sell data.</li>
        <li>Story ideas are processed by our AI providers under terms that don&apos;t train on your data.</li>
        <li>You can download or permanently delete all of your data at any time in Settings.</li>
      </ul>
    </main>
  );
}
