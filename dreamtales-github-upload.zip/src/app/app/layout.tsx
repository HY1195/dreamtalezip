import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

// Everything under /app needs a signed-in, consented parent with at least one child.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.parentalConsentAt) redirect("/onboarding");
  const hasChild = (await db.child.count({ where: { userId: user.id } })) > 0;
  if (!hasChild) redirect("/onboarding");
  return <>{children}</>;
}
