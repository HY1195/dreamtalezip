import type { Metadata, Viewport } from "next";
import { Nunito, Young_Serif } from "next/font/google";
import "./globals.css";

// Working type pairing (PRD §10: final style to be decided in the design phase).
const display = Young_Serif({ weight: "400", subsets: ["latin"], variable: "--font-display" });
const body = Nunito({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "DreamTales: bedtime stories made for your child",
  description: "A new bedtime story starring your child, written in seconds and read aloud in a calm voice.",
  appleWebApp: { capable: true, title: "DreamTales", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#1b2240",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}
