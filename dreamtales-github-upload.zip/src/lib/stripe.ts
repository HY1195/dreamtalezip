import Stripe from "stripe";
import { HttpError } from "./auth";

let client: Stripe | null = null;

export function stripe(): Stripe {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new HttpError(503, "Payments aren't set up yet.", "billing_unavailable");
  client ??= new Stripe(key);
  return client;
}
