// Narration voices (PRD §6.1 item 4): a few free voices, more on the paid plan.
// Provider voice IDs come from env vars so the team can pick voices in the
// ElevenLabs voice library without code changes.

export type Voice = {
  id: string;
  label: string;
  description: string;
  premium: boolean;
  envVar: string;
};

export const VOICES: Voice[] = [
  { id: "warm", label: "Warm", description: "Soft, warm and soothing", premium: false, envVar: "VOICE_ID_WARM" },
  { id: "gentle", label: "Gentle", description: "Calm and low", premium: false, envVar: "VOICE_ID_GENTLE" },
  { id: "storyteller", label: "Storyteller", description: "Classic bedtime narrator", premium: true, envVar: "VOICE_ID_STORYTELLER" },
  { id: "grandpa", label: "Grandpa", description: "Kind, grandparent-like", premium: true, envVar: "VOICE_ID_GRANDPA" },
  { id: "whisper", label: "Whisper", description: "Quiet and sleepy", premium: true, envVar: "VOICE_ID_WHISPER" },
  { id: "cheerful", label: "Cheerful", description: "Bright, for funny stories", premium: true, envVar: "VOICE_ID_CHEERFUL" },
];

export function getVoice(id: string): Voice | undefined {
  return VOICES.find((v) => v.id === id);
}

export function providerVoiceId(voice: Voice): string {
  const value = process.env[voice.envVar];
  if (!value) {
    throw new Error(`Missing ${voice.envVar}: set it to an ElevenLabs voice ID in .env`);
  }
  return value;
}
