import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { del, put } from "@vercel/blob";

// Saved story audio (PRD §6.1 Library; replays cost nothing).
// - On Vercel: Vercel Blob (served from its CDN).
// - Locally (no BLOB_READ_WRITE_TOKEN): files in ./.data/audio.
//
// Blob URLs are public but unguessable (random suffix). They are only ever
// handed to the signed-in owner by /api/stories/[id]/audio. If the legal review
// requires it, switch to private storage with short-lived signed URLs.

const useBlob = () => Boolean(process.env.BLOB_READ_WRITE_TOKEN);
const localDir = () => path.resolve("./.data/audio");

function safeName(name: string): string {
  if (!/^[a-zA-Z0-9_-]+\.mp3$/.test(name)) throw new Error("Invalid audio name");
  return name;
}

/** Saves audio and returns a storage key to keep on the Story row. */
export async function saveAudio(name: string, data: Uint8Array): Promise<string> {
  safeName(name);
  if (useBlob()) {
    const blob = await put(`stories/${name}`, Buffer.from(data), {
      access: "public",
      contentType: "audio/mpeg",
      addRandomSuffix: true,
    });
    return blob.url;
  }
  await mkdir(localDir(), { recursive: true });
  await writeFile(path.join(localDir(), name), data);
  return `local:${name}`;
}

/** Either a URL to redirect to (Blob) or the bytes (local dev). */
export async function getAudio(key: string): Promise<{ url: string } | { data: Buffer } | null> {
  if (key.startsWith("local:")) {
    try {
      return { data: await readFile(path.join(localDir(), safeName(key.slice(6)))) };
    } catch {
      return null;
    }
  }
  return { url: key };
}

export async function deleteAudio(key: string): Promise<void> {
  if (key.startsWith("local:")) {
    await rm(path.join(localDir(), safeName(key.slice(6))), { force: true });
    return;
  }
  if (useBlob()) await del(key);
}
