import Anthropic from "@anthropic-ai/sdk";

// One shared client. Reads ANTHROPIC_API_KEY from the environment.
export const anthropic = new Anthropic({ maxRetries: 2 });

export const STORY_MODEL = process.env.STORY_MODEL ?? "claude-opus-5-5";
export const SAFETY_MODEL = process.env.SAFETY_MODEL ?? "claude-opus-5-5";

export type Effort = "low" | "medium" | "high";
export const STORY_EFFORT: Effort = (process.env.STORY_EFFORT as Effort) ?? "low";
