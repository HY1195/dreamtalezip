// Text-to-speech behind a small interface so the provider can be swapped
// (PRD §8.2). The default implementation streams MP3 from ElevenLabs.

export interface TtsProvider {
  /** Returns a stream of MP3 bytes for `text`, starting as soon as audio is ready. */
  synthesize(text: string, voiceId: string, opts?: { previousText?: string }): Promise<ReadableStream<Uint8Array>>;
}

class ElevenLabsTts implements TtsProvider {
  async synthesize(
    text: string,
    voiceId: string,
    opts?: { previousText?: string },
  ): Promise<ReadableStream<Uint8Array>> {
    const key = process.env.ELEVENLABS_API_KEY;
    if (!key) throw new Error("ELEVENLABS_API_KEY is not set");
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}/stream?output_format=mp3_44100_128`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "xi-api-key": key, "Content-Type": "application/json", Accept: "audio/mpeg" },
      body: JSON.stringify({
        text,
        model_id: process.env.ELEVENLABS_MODEL_ID ?? "eleven_flash_v2_5",
        // previous_text keeps intonation continuous across chunks.
        previous_text: opts?.previousText,
        voice_settings: { stability: 0.6, similarity_boost: 0.75, speed: 0.9 },
      }),
    });
    if (!res.ok || !res.body) {
      throw new Error(`TTS failed: ${res.status} ${await res.text().catch(() => "")}`);
    }
    return res.body;
  }
}

export const tts: TtsProvider = new ElevenLabsTts();
