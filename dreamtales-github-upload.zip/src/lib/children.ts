import { z } from "zod";
import { HttpError } from "./auth";
import { MAX_AGE, MAX_FAVORITES, MIN_AGE } from "./config";
import { checkParentInput } from "./story/safety";

const COLORS = ["#8b7cf6", "#f59e8b", "#5fb8a8", "#e8b04b", "#6aa6e8", "#d98cc8"];

export const ChildInput = z.object({
  // First name or nickname only (data minimization, PRD §8.5)
  name: z.string().trim().min(1).max(30),
  pronunciation: z.string().trim().max(40).nullish(),
  // Ages outside 2-10 are accepted but mapped to the nearest band (PRD corner cases)
  age: z.number().int().min(0).max(17),
  favorites: z.array(z.string().trim().min(1).max(40)).max(MAX_FAVORITES).default([]),
  color: z.string().regex(/^#[0-9a-f]{6}$/i).optional(),
});
export type ChildInput = z.infer<typeof ChildInput>;

export function pickColor(index: number): string {
  return COLORS[index % COLORS.length];
}

export function ageNote(age: number): string | null {
  if (age < MIN_AGE) return `Stories are written for ages ${MIN_AGE}-${MAX_AGE}; we'll use our youngest style.`;
  if (age > MAX_AGE) return `Stories are written for ages ${MIN_AGE}-${MAX_AGE}; we'll use our oldest style.`;
  return null;
}

/** Names and favorites are spoken in stories, so they're checked like requests. */
export async function moderateChild(input: ChildInput): Promise<void> {
  const text = [input.name, input.pronunciation, ...input.favorites].filter(Boolean).join(" | ");
  const verdict = await checkParentInput(`Child nickname and favorite things: ${text}`);
  if (!verdict.allowed) {
    throw new HttpError(
      422,
      "One of those words can't be used in a children's story. Please try something else.",
      "child_input_blocked",
    );
  }
}
