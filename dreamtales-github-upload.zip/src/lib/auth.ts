import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "@prisma/client";
import { db } from "./db";

// Passwordless email sign-in with a signed session cookie.
// Google / Apple sign-in (PRD FR-1) can be added with Auth.js or Clerk later;
// everything else in the app only depends on getCurrentUser().

const COOKIE = "dt_session";
const SESSION_DAYS = 60; // long-lived: parents shouldn't sign in again at bedtime
const LOGIN_LINK_MINUTES = 15;

function secret(): Uint8Array {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new Error("SESSION_SECRET must be set (16+ chars)");
  return new TextEncoder().encode(s);
}

export function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export function newToken(): string {
  return randomBytes(32).toString("base64url");
}

export async function createLoginToken(email: string): Promise<string> {
  const token = newToken();
  await db.loginToken.create({
    data: {
      email,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + LOGIN_LINK_MINUTES * 60_000),
    },
  });
  return token;
}

/** Consumes a sign-in token. Returns the user (created on first sign-in) or null. */
export async function consumeLoginToken(token: string): Promise<User | null> {
  const record = await db.loginToken.findUnique({ where: { tokenHash: hashToken(token) } });
  if (!record || record.usedAt || record.expiresAt < new Date()) return null;
  // Mark used atomically so a link can't be used twice.
  const updated = await db.loginToken.updateMany({
    where: { id: record.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (updated.count === 0) return null;
  return db.user.upsert({
    where: { email: record.email },
    update: {},
    create: { email: record.email },
  });
}

export async function startSession(user: User): Promise<void> {
  const jwt = await new SignJWT({ v: user.sessionVersion })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(secret());
  const jar = await cookies();
  jar.set(COOKIE, jwt, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 3600,
  });
}

export async function endSession(): Promise<void> {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const jar = await cookies();
  const raw = jar.get(COOKIE)?.value;
  if (!raw) return null;
  try {
    const { payload } = await jwtVerify(raw, secret());
    if (!payload.sub) return null;
    const user = await db.user.findUnique({ where: { id: payload.sub } });
    // "Sign out all devices" bumps sessionVersion, which invalidates older cookies.
    if (!user || user.sessionVersion !== payload.v) return null;
    return user;
  } catch {
    return null;
  }
}

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message);
  }
}

/** For API routes: the signed-in user, or a 401. */
export async function requireUser(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new HttpError(401, "Please sign in.", "unauthenticated");
  return user;
}

/** For API routes that touch child data: also requires COPPA consent. */
export async function requireConsentedUser(): Promise<User> {
  const user = await requireUser();
  if (!user.adultConfirmedAt || !user.parentalConsentAt) {
    throw new HttpError(403, "Parental consent is required first.", "consent_required");
  }
  return user;
}
