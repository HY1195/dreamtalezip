import type Stripe from "stripe";
import { db } from "./db";

const ACTIVE = new Set(["active", "trialing", "past_due"]);

/** Copies a Stripe subscription's state onto the user. Safe to call repeatedly. */
export async function syncSubscription(sub: Stripe.Subscription): Promise<void> {
  const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer.id;
  const periodEnd = sub.items.data[0]?.current_period_end;
  const active = ACTIVE.has(sub.status);
  await db.user.updateMany({
    where: { stripeCustomerId: customerId },
    data: {
      stripeSubscriptionId: sub.id,
      subscriptionStatus: sub.status,
      plan: active ? "paid" : "free",
      // After cancellation, paid features stay on until the period ends (PRD corner cases).
      currentPeriodEnd: periodEnd ? new Date(periodEnd * 1000) : null,
    },
  });
}
