// Browser-side helpers shared by the app screens.

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string,
    public data?: Record<string, unknown>,
  ) {
    super(message);
  }
}

export async function api<T = unknown>(path: string, init?: { method?: string; body?: unknown }): Promise<T> {
  const res = await fetch(path, {
    method: init?.method ?? (init?.body ? "POST" : "GET"),
    headers: init?.body ? { "Content-Type": "application/json" } : undefined,
    body: init?.body ? JSON.stringify(init.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && typeof window !== "undefined") window.location.href = "/login";
    throw new ApiError(data.error ?? "Something went wrong.", res.status, data.code, data);
  }
  return data as T;
}

export type Me = {
  user: { email: string; consented: boolean; paid: boolean; subscriptionStatus: string | null; currentPeriodEnd: string | null };
  quota: { plan: "free" | "paid"; used: number; limit: number; remaining: number; nextAvailableAt: string | null };
  children: {
    id: string;
    name: string;
    pronunciation: string | null;
    age: number;
    favorites: string[];
    color: string;
    lastSettings: StorySettings | null;
  }[];
  voices: { id: string; label: string; description: string; premium: boolean; available: boolean }[];
};

export type StorySettings = { styles: string[]; lengthMinutes: number; voiceId: string; useFavorites: boolean };

export type StoryDto = {
  id: string;
  childId: string;
  childName?: string;
  childColor?: string;
  title: string | null;
  text: string | null;
  styles: string[];
  lengthMinutes: number;
  voiceId: string;
  status: "pending" | "streaming" | "ready" | "failed" | "blocked";
  hasAudio: boolean;
  saved: boolean;
  rating: number | null;
  reported: boolean;
  createdAt: string;
};

export function newIdempotencyKey(): string {
  return crypto.randomUUID();
}

export function formatNextStory(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { weekday: "long", hour: "numeric", minute: "2-digit" });
}
