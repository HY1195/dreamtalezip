// Product rules from the PRD, kept in one place so they're easy to change.

export const FREE_STORIES_PER_WEEK = 3;
// Fair-use cap for the paid plan (PRD §8.6). Not a budget limit, just abuse protection.
export const PAID_STORIES_PER_MONTH = 60;

export const STORY_LENGTHS = [3, 5, 10] as const;
export type StoryLength = (typeof STORY_LENGTHS)[number];

// Calm narration pace (PRD §8.3): ~125 words per minute.
export const WORDS_PER_MINUTE = 125;

export const MIN_AGE = 2;
export const MAX_AGE = 10;

export const MAX_REQUEST_CHARS = 200;
export const MAX_FAVORITES = 10;
export const FAVORITES_PER_STORY = 3;

export const STYLES = [
  { id: "adventure", label: "Adventure", emoji: "🧭" },
  { id: "animals", label: "Animals", emoji: "🦊" },
  { id: "fairy_tale", label: "Fairy tale", emoji: "🏰" },
  { id: "space", label: "Space", emoji: "🚀" },
  { id: "funny", label: "Funny", emoji: "😄" },
  { id: "calm", label: "Calm & sleepy", emoji: "🌙" },
  { id: "kindness", label: "Kindness & values", emoji: "💛" },
] as const;
export type StyleId = (typeof STYLES)[number]["id"];
export const STYLE_IDS = STYLES.map((s) => s.id) as [StyleId, ...StyleId[]];

export const SLEEP_SOUNDS = [
  { id: "rain", label: "Rain" },
  { id: "ocean", label: "Ocean" },
  { id: "white", label: "White noise" },
] as const;
export const SLEEP_FADE_MINUTES = [15, 30, 45] as const;

export function appUrl(path = ""): string {
  const base = process.env.APP_URL ?? "http://localhost:3000";
  return `${base.replace(/\/$/, "")}${path}`;
}
