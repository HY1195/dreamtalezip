import type { Story } from "@prisma/client";
import { db } from "./db";

// A story stuck in "streaming" (e.g. the server restarted mid-story) is failed
// and refunded after this long.
const STALE_STREAMING_MS = 10 * 60_000;

export async function expireIfStale(story: Story): Promise<Story> {
  if (
    (story.status === "streaming" || story.status === "pending") &&
    Date.now() - story.createdAt.getTime() > STALE_STREAMING_MS
  ) {
    return db.story.update({
      where: { id: story.id },
      data: { status: "failed", countsTowardQuota: false },
    });
  }
  return story;
}

export function publicStory(story: Story & { child?: { name: string; color: string } | null }) {
  return {
    id: story.id,
    childId: story.childId,
    childName: story.child?.name,
    childColor: story.child?.color,
    title: story.title,
    text: story.status === "ready" ? story.text : null,
    styles: story.styles,
    lengthMinutes: story.lengthMinutes,
    voiceId: story.voiceId,
    status: story.status,
    hasAudio: Boolean(story.audioKey),
    saved: story.saved,
    rating: story.rating,
    reported: story.reported,
    createdAt: story.createdAt,
  };
}
