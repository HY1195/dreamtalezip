import type { User } from "@prisma/client";
import { db } from "./db";
import { FREE_STORIES_PER_WEEK, PAID_STORIES_PER_MONTH } from "./config";

const DAY = 24 * 3600 * 1000;

export function isPaid(user: User): boolean {
  if (user.plan !== "paid") return false;
  // Keep paid features until the end of the period they paid for (PRD corner cases).
  if (user.currentPeriodEnd && user.currentPeriodEnd < new Date()) return false;
  return true;
}

export type QuotaStatus = {
  plan: "free" | "paid";
  used: number;
  limit: number;
  remaining: number;
  /** When the next free story becomes available (rolling window), if out of stories. */
  nextAvailableAt: string | null;
};

/**
 * Free plan: 3 new stories per rolling 7 days. Paid plan: fair-use cap per rolling 30 days.
 * Replays of saved stories never count. Failed stories are refunded (countsTowardQuota=false).
 */
export async function getQuota(user: User): Promise<QuotaStatus> {
  const paid = isPaid(user);
  const windowMs = paid ? 30 * DAY : 7 * DAY;
  const limit = paid ? PAID_STORIES_PER_MONTH : FREE_STORIES_PER_WEEK;
  const since = new Date(Date.now() - windowMs);

  const counted = await db.story.findMany({
    where: {
      userId: user.id,
      countsTowardQuota: true,
      status: { notIn: ["failed", "blocked"] },
      createdAt: { gte: since },
    },
    orderBy: { createdAt: "asc" },
    select: { createdAt: true },
  });

  const used = counted.length;
  const remaining = Math.max(0, limit - used);
  let nextAvailableAt: string | null = null;
  if (remaining === 0 && counted.length > 0) {
    // The oldest counted story drops out of the window first.
    const oldest = counted[used - limit]?.createdAt ?? counted[0].createdAt;
    nextAvailableAt = new Date(oldest.getTime() + windowMs).toISOString();
  }
  return { plan: paid ? "paid" : "free", used, limit, remaining, nextAvailableAt };
}
