// Sends transactional email. In dev (no RESEND_API_KEY) the email is printed
// to the server console so you can click the link locally.

export async function sendEmail(to: string, subject: string, text: string): Promise<void> {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.log(`\n=== EMAIL (dev) ===\nTo: ${to}\nSubject: ${subject}\n\n${text}\n===================\n`);
    return;
  }
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM ?? "DreamTales <hello@example.com>",
      to,
      subject,
      text,
    }),
  });
  if (!res.ok) {
    throw new Error(`Email send failed: ${res.status} ${await res.text()}`);
  }
}
