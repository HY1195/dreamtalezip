// Turns a stream of text deltas into speakable chunks (PRD §8.2 step 2).
//
// - The "TITLE: ..." first line is pulled out and never spoken.
// - The FIRST chunk is a single sentence, emitted the moment it's complete,
//   so the voice can start as early as possible.
// - Later chunks group sentences up to ~MAX_CHARS, so there are fewer TTS calls
//   and the voice sounds more natural.

const FIRST_CHUNK_MIN_CHARS = 20;
const MAX_CHARS = 280;
// Sentence end: punctuation, optional closing quotes/brackets, then whitespace.
const SENTENCE_END = /[.!?…]+["'”’)\]]*\s+/g;

export class StoryChunker {
  private buffer = "";
  private pending = "";
  private titleDone = false;
  private emittedAny = false;
  title: string | null = null;
  /** The story text without the title line. */
  fullText = "";

  constructor(private onChunk: (chunk: string) => void) {}

  push(delta: string): void {
    this.buffer += delta;

    if (!this.titleDone) {
      const newline = this.buffer.indexOf("\n");
      if (newline === -1) {
        // Wait for the title line, unless the model clearly skipped it.
        if (this.buffer.length < 200 || /^\s*TITLE:/i.test(this.buffer)) return;
        this.titleDone = true;
      } else {
        const firstLine = this.buffer.slice(0, newline);
        const match = /^\s*TITLE:\s*(.+)$/i.exec(firstLine);
        if (match) {
          this.title = match[1].trim().replace(/^["“]|["”]$/g, "");
          this.buffer = this.buffer.slice(newline + 1);
        }
        this.titleDone = true;
      }
    }

    this.drainSentences();
  }

  /** Call when the model has finished. Emits whatever is left. */
  end(): void {
    this.titleDone = true;
    const rest = (this.pending + this.buffer).trim();
    this.fullText += this.buffer;
    this.buffer = "";
    this.pending = "";
    if (rest) this.emit(rest);
    this.fullText = this.fullText.trim();
  }

  private drainSentences(): void {
    SENTENCE_END.lastIndex = 0;
    let match: RegExpExecArray | null;
    let consumed = 0;
    while ((match = SENTENCE_END.exec(this.buffer)) !== null) {
      const end = match.index + match[0].length;
      this.addSentence(this.buffer.slice(consumed, end));
      consumed = end;
    }
    if (consumed > 0) {
      this.fullText += this.buffer.slice(0, consumed);
      this.buffer = this.buffer.slice(consumed);
    }
  }

  private addSentence(sentence: string): void {
    if (!this.emittedAny) {
      this.pending += sentence;
      if (this.pending.trim().length >= FIRST_CHUNK_MIN_CHARS) {
        this.emit(this.pending.trim());
        this.pending = "";
      }
      return;
    }
    if ((this.pending + sentence).length > MAX_CHARS && this.pending.trim()) {
      this.emit(this.pending.trim());
      this.pending = "";
    }
    this.pending += sentence;
  }

  private emit(chunk: string): void {
    this.emittedAny = true;
    this.onChunk(chunk);
  }
}
