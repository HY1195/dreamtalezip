// Ordered, concurrent TTS: chunks are synthesized in parallel (up to a limit)
// as soon as the story text arrives, but their audio is played strictly in order.
// The chunk at the head of the line streams live; later ones buffer in memory.

class ChunkAudio {
  parts: Uint8Array[] = [];
  done = false;
  error: unknown = null;
  private waiters: (() => void)[] = [];

  push(part: Uint8Array) {
    this.parts.push(part);
    this.wake();
  }
  finish(error?: unknown) {
    this.done = true;
    if (error) this.error = error;
    this.wake();
  }
  private wake() {
    const w = this.waiters;
    this.waiters = [];
    w.forEach((fn) => fn());
  }
  async *read(): AsyncGenerator<Uint8Array> {
    let i = 0;
    for (;;) {
      while (i < this.parts.length) yield this.parts[i++];
      if (this.done) {
        if (this.error) throw this.error;
        return;
      }
      await new Promise<void>((resolve) => this.waiters.push(resolve));
    }
  }
}

/** FIFO semaphore so chunks claim TTS slots in story order. */
class Semaphore {
  private queue: (() => void)[] = [];
  constructor(private free: number) {}
  async acquire(): Promise<void> {
    if (this.free > 0) {
      this.free--;
      return;
    }
    await new Promise<void>((resolve) => this.queue.push(resolve));
  }
  release(): void {
    const next = this.queue.shift();
    if (next) next();
    else this.free++;
  }
}

export class OrderedAudioQueue {
  private chunks: ChunkAudio[] = [];
  private closed = false;
  private waiters: (() => void)[] = [];
  private slots: Semaphore;

  constructor(
    private synthesize: (text: string, previousText: string) => Promise<ReadableStream<Uint8Array>>,
    concurrency = 3,
  ) {
    this.slots = new Semaphore(concurrency);
  }

  /** Queue a text chunk for synthesis. Returns immediately. */
  add(text: string, previousText: string): void {
    const audio = new ChunkAudio();
    this.chunks.push(audio);
    this.wake();
    void (async () => {
      await this.slots.acquire();
      try {
        const stream = await this.synthesize(text, previousText);
        const reader = stream.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) audio.push(value);
        }
        audio.finish();
      } catch (err) {
        audio.finish(err);
      } finally {
        this.slots.release();
      }
    })();
  }

  /** No more chunks will be added. */
  close(): void {
    this.closed = true;
    this.wake();
  }

  private wake() {
    const w = this.waiters;
    this.waiters = [];
    w.forEach((fn) => fn());
  }

  /** Audio bytes in story order. Throws if any chunk's synthesis failed. */
  async *read(): AsyncGenerator<Uint8Array> {
    let i = 0;
    for (;;) {
      while (i < this.chunks.length) {
        yield* this.chunks[i++].read();
      }
      if (this.closed) return;
      await new Promise<void>((resolve) => this.waiters.push(resolve));
    }
  }
}
