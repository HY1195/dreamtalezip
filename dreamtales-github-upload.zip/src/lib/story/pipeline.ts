import Anthropic from "@anthropic-ai/sdk";
import { db } from "../db";
import { anthropic, STORY_EFFORT, STORY_MODEL } from "../anthropic";
import { FAVORITES_PER_STORY, STYLE_IDS, type StyleId } from "../config";
import { getVoice, providerVoiceId } from "../voices";
import { tts } from "../tts";
import { saveAudio } from "../storage";
import { StoryChunker } from "./chunker";
import { OrderedAudioQueue } from "./audio-queue";
import { buildUserPrompt, pickFavorites, STORY_SYSTEM_PROMPT } from "./prompt";
import { sentenceLooksUnsafe } from "./safety";

// The streaming story pipeline (PRD §8.2):
//
//   Claude (streamed text) -> sentence chunker -> safety check per chunk
//     -> ElevenLabs streaming TTS (parallel, ordered) -> MP3 bytes -> browser
//
// Narration starts after the FIRST sentence is written and voiced, so the
// parent hears audio within the 5-second target while the rest of the story is
// still being written. All audio is also collected and saved to the library.

const CLOSING_LINE = "And with that, it was time to rest. Snuggle in, close your eyes, and sleep tight. Goodnight.";

export type PipelineResult = { status: "ready" | "failed" | "blocked" };

/**
 * Generates and voices a story. `onAudio` receives MP3 bytes in order as soon as
 * they're ready. Runs to completion even if the listener goes away, so the
 * story is still saved (PRD corner case: parent leaves mid-generation).
 */
export async function runStoryPipeline(
  storyId: string,
  onAudio: (bytes: Uint8Array) => void,
): Promise<PipelineResult> {
  const story = await db.story.findUniqueOrThrow({
    where: { id: storyId },
    include: { child: true },
  });
  const voice = getVoice(story.voiceId);
  if (!voice) throw new Error(`Unknown voice ${story.voiceId}`);
  const voiceProviderId = providerVoiceId(voice);

  const recent = await db.story.findMany({
    where: { childId: story.childId, status: "ready", id: { not: story.id } },
    orderBy: { createdAt: "desc" },
    take: 5,
    select: { title: true },
  });
  const storyCount = await db.story.count({ where: { childId: story.childId } });

  const userPrompt = buildUserPrompt({
    childName: story.child.name,
    age: story.child.age,
    styles: story.styles.filter((s): s is StyleId => (STYLE_IDS as string[]).includes(s)),
    lengthMinutes: story.lengthMinutes,
    favorites: story.useFavorites ? pickFavorites(story.child.favorites, FAVORITES_PER_STORY, storyCount) : [],
    request: story.request,
    recentTitles: recent.map((r) => r.title).filter((t): t is string => Boolean(t)),
  });

  // The voice says the child's name the way the parent spelled it phonetically.
  const speakable = (text: string) =>
    story.child.pronunciation
      ? text.replace(new RegExp(`\\b${escapeRegExp(story.child.name)}\\b`, "g"), story.child.pronunciation)
      : text;

  const queue = new OrderedAudioQueue((text, previousText) =>
    tts.synthesize(speakable(text), voiceProviderId, { previousText: speakable(previousText) }),
  );

  let lastSpoken = "";
  let flagged = false;
  const chunker = new StoryChunker((chunk) => {
    if (sentenceLooksUnsafe(chunk)) {
      // Never voice it. Flag the story for the review queue.
      flagged = true;
      console.warn(`[story ${storyId}] chunk blocked by output safety check`);
      return;
    }
    queue.add(chunk, lastSpoken);
    lastSpoken = chunk;
  });

  // Consume audio in order while the text is still being written.
  const audioParts: Uint8Array[] = [];
  let firstAudioAt: number | null = null;
  const audioDone = (async () => {
    for await (const part of queue.read()) {
      if (firstAudioAt === null) firstAudioAt = Date.now();
      audioParts.push(part);
      onAudio(part);
    }
  })();

  let status: PipelineResult["status"] = "ready";
  try {
    const stream = anthropic.beta.messages.stream({
      model: STORY_MODEL,
      max_tokens: 16000,
      // Refusal fallbacks: if a safety classifier declines, the API retries on a
      // fallback model in the same call, so the parent still gets a story.
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      // Effort is the main latency lever: lower effort = faster first sentence.
      output_config: { effort: STORY_EFFORT },
      // Identical system prompt on every request -> prompt caching.
      system: [{ type: "text", text: STORY_SYSTEM_PROMPT, cache_control: { type: "ephemeral" } }],
      messages: [{ role: "user", content: userPrompt }],
    });

    for await (const event of stream) {
      if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
        chunker.push(event.delta.text);
      }
    }
    const final = await stream.finalMessage();

    if (final.stop_reason === "refusal") {
      // Every model in the fallback chain declined.
      status = "blocked";
    } else if (final.stop_reason === "max_tokens") {
      console.warn(`[story ${storyId}] hit max_tokens; ending gently`);
    }
    chunker.end();
    // Make sure every story ends calmly, even if it was cut short.
    // (Only if something was already spoken; otherwise the player shows a message.)
    if (lastSpoken && (status !== "ready" || final.stop_reason !== "end_turn" || flagged)) {
      queue.add(CLOSING_LINE, lastSpoken);
    }
  } catch (err) {
    status = "failed";
    logError(storyId, err);
    chunker.end();
    if (lastSpoken) queue.add(CLOSING_LINE, lastSpoken);
  } finally {
    queue.close();
  }

  try {
    await audioDone;
  } catch (err) {
    status = "failed";
    logError(storyId, err);
  }

  const createdAt = story.createdAt.getTime();
  let audioKey: string | null = null;
  if (status === "ready" && audioParts.length > 0) {
    audioKey = await saveAudio(`${story.id}.mp3`, concat(audioParts));
  }

  await db.story.update({
    where: { id: story.id },
    data: {
      status,
      title: chunker.title ?? `${story.child.name}'s bedtime story`,
      text: chunker.fullText,
      audioKey,
      reported: flagged || undefined,
      // Failed and blocked stories don't use up the parent's free stories.
      countsTowardQuota: status === "ready",
      timeToFirstAudioMs: firstAudioAt ? firstAudioAt - createdAt : null,
    },
  });

  return { status };
}

function logError(storyId: string, err: unknown) {
  if (err instanceof Anthropic.RateLimitError) {
    console.error(`[story ${storyId}] Claude rate limited`, err.message);
  } else if (err instanceof Anthropic.APIError) {
    console.error(`[story ${storyId}] Claude API error ${err.status}`, err.message);
  } else {
    console.error(`[story ${storyId}] pipeline error`, err);
  }
}

function concat(parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((n, p) => n + p.byteLength, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.byteLength;
  }
  return out;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
